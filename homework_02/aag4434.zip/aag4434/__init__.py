from .main import MainLinear, MainDeep

# Load the models
linear_model = MainLinear()
deep_model = MainDeep()