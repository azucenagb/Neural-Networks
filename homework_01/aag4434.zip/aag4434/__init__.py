from .main import Main

# Load the model (if needed)
main = Main()
